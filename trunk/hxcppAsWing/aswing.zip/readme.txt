Hi,  hxcpp aswing 2.0  is an unstable development version    now 

I myself, after working hours to the New Year



hxcpp aswing  it have some memory recovery bug,need some of the testing and characterization


if you can help me

Welcome!

2011 -11 -17
